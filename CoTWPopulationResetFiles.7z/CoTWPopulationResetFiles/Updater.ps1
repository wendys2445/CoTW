#Notifying User of Update and asking them to continue﻿
Write-Host "Update Required! Press any Key To Continue..." -ForegroundColor Green
$x = $host.ui.RawUI.ReadKey("NoEcho,IncludeKeyDown")
Write-Host "Updating Please Wait..."
Start-Sleep -Seconds 1
#Getting most recent script from Github and replacing old script
Get-Process
for ($i = 1; $i -le 100; $i++ ) {
    Write-Progress -Activity "Updating" -Status "$i% Complete:" -PercentComplete $i
    Start-Sleep -Milliseconds 15
}


Invoke-WebRequest -Uri https://github.com/wendys2445/CoTW/blob/main/test.zip -OutFile C:\Users\Public\CoTWPopulationResetFiles.7z
Expand-Archive -LiteralPath C:\Users\Public\CoTWPopulationResetFiles\CoTWPopulationResetFiles.7z -DestinationPath C:\Users\Public\CoTWPopulationResetFilesNew
C:\Users\Public\CoTWPopulationResetFilesNew\Updatefinish.ps1
Exit









