Remove-Item C:\Users\Public\CoTWPopulationFilesReset
Rename-Item -Path "C:\Users\Public\CoTWPopulationFilesResetUpdate" -NewName "C:\Users\Public\CoTWPopulationFilesReset"
Write-Host "Update Complete! Press Any key To Continue and then relaunch the script to use." -ForegroundColor Green
$x = $host.ui.RawUI.ReadKey("NoEcho,IncludeKeyDown")